/**
 * 
 */
/**
 * 
 */
module Redes {
	requires java.desktop;
}