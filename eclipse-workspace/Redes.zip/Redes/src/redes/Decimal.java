package redes;

public class Decimal {
	protected int decimal;
	
	public Decimal(int decimal) {
		this.decimal = decimal;
	}

	public Decimal() {
		// TODO Auto-generated constructor stub
	}

	public int getDecimal() {
		return decimal;
	}

	public void setDecimal(int decimal) {
		this.decimal = decimal;
	}

}
