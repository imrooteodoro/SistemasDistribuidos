package redes;

import javax.swing.JOptionPane;

public class Binary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DecimalList n = new DecimalList();
		n.createDecList();
		n.calcdecimal();
	}

}
