package redes;

public class Address {
	private String binario;
	
	
	public String getBinario() {
		return binario;
	}

	public void setBinario(String binario) {
		this.binario = binario;
	}

}
